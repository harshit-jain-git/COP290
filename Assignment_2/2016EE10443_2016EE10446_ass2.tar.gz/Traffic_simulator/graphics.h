#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <GLFW/glfw3.h>

void drawCube(float a, float b, float c);

#endif