#include "Vehicle.h"

Vehicle::Vehicle()
{
    
}