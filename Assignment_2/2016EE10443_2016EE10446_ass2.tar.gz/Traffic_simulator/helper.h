#ifndef HELPER_H
#define HELPER_H

void load_configuration();
void tc();
void light(int signal);

#endif