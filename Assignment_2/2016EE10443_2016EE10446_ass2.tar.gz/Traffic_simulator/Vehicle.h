#ifndef VEHICLE_H
#define VEHICLE_H

#include "Tuple.h"
#include "Colors.h"
#include "graphics.h"
#include <GLFW/glfw3.h>
using namespace std;

class Vehicle
{
public:
    Vehicle();
};

#endif