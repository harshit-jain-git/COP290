double pthread_multiply(float* A,float* B,float* C,int m,int l,int n);
//void* multiply(void* arg);